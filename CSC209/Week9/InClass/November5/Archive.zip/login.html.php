<html>
<body>

<form action="validation.html.php" method="post">
Username: <input type="text" name="username"><br>
Password: <input type="text" name="password"><br>
<input type="submit">
</form>
</body>
</html>