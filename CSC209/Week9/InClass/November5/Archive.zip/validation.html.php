<?php
    $file= fopen("users.json", "r");   
    $jsonString=file_get_contents("users.json"); 
    $usersObject= json_decode($jsonString);


    $currentUsername= $_POST["username"];
    $currentPassword= $_POST["password"];
    $logInFound= false; 

    foreach($usersObject as $user){
        if($user->username==$currentUsername){
            if($user->password==$currentPassword){
                echo "Welcome ".$_POST["username"]. "<br>";
                echo "Your password is ".$_POST["password"];
                $logInFound= true; 
            }
        }
    }
    if($logInFound= false){
        echo 'alert("Username and Password incorrect. Please try again!")'; 
    }



?>